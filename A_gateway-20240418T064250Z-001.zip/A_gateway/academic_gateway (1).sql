-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Apr 17, 2024 at 11:12 PM
-- Server version: 8.0.30
-- PHP Version: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `academic_gateway`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int NOT NULL,
  `A_username` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `password` varchar(255) NOT NULL,
  `section` varchar(255) NOT NULL,
  `pin` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `A_username`, `password`, `section`, `pin`) VALUES
(1, 'manny', 'manny', '2-B', '123'),
(2, 'admin', 'admin', '2-A', '890'),
(3, '123', '123', '123', '');

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `id` int NOT NULL,
  `admin_id` varchar(20) DEFAULT NULL,
  `fullname` varchar(100) DEFAULT NULL,
  `password` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`id`, `admin_id`, `fullname`, `password`) VALUES
(2, '2210132-1', 'Manny Merino', 'manny');

-- --------------------------------------------------------

--
-- Table structure for table `assessment_schedule`
--

CREATE TABLE `assessment_schedule` (
  `id` int NOT NULL,
  `title` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  `date` date NOT NULL,
  `year_section` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `assessment_schedule`
--

INSERT INTO `assessment_schedule` (`id`, `title`, `type`, `date`, `year_section`, `status`) VALUES
(7, 'Network Basics', 'Quiz', '2024-04-16', '2-B', 'expired'),
(8, 'Network Basics', 'Quiz', '2024-04-19', '2-B', 'active'),
(9, 'Quantitative Methods', 'Quiz', '2024-04-15', '2-B', 'expired'),
(10, 'science', 'Exam', '2024-04-18', '2-B', 'active');

-- --------------------------------------------------------

--
-- Table structure for table `cashier`
--

CREATE TABLE `cashier` (
  `id` int NOT NULL,
  `student_ID` varchar(20) DEFAULT NULL,
  `priority_queue_number` int DEFAULT NULL,
  `time` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `status` varchar(255) NOT NULL,
  `s_stat` varchar(255) NOT NULL,
  `num_attempts` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `cashier`
--

INSERT INTO `cashier` (`id`, `student_ID`, `priority_queue_number`, `time`, `status`, `s_stat`, `num_attempts`) VALUES
(1298, '2210132-1', 3001, '2024-03-31 04:39:55', 'expired', 'served', '0'),
(1299, '2210132-1', 3002, '2024-03-31 04:40:00', 'expired', 'served', '0'),
(1300, '2210132-1', 3003, '2024-03-31 04:40:07', 'expired', 'served', '0'),
(1301, '2210132-1', 3004, '2024-03-31 04:40:12', 'expired', 'served', '0'),
(1302, '2210132-1', 3005, '2024-03-31 04:40:18', 'expired', 'served', '0'),
(1303, '2210134-2', 3006, '2024-03-31 05:09:35', 'expired', 'served', '0'),
(1304, '2210134-2', 3007, '2024-03-31 05:11:17', 'expired', 'served', '0'),
(1305, '2210132-1', 3008, '2024-04-17 14:57:59', 'active', 'waiting', '5');

-- --------------------------------------------------------

--
-- Table structure for table `class_schedule`
--

CREATE TABLE `class_schedule` (
  `id` int NOT NULL,
  `type_class` varchar(255) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `date` date NOT NULL,
  `year_section` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `class_schedule`
--

INSERT INTO `class_schedule` (`id`, `type_class`, `subject`, `date`, `year_section`, `status`) VALUES
(1, 'NO CLASS HOLIDAY', 'NONE', '2024-04-17', '2-B', 'active'),
(2, 'MAKE-UP CLASS', 'Quantitative Methods', '2024-04-18', '2-B', 'active'),
(3, 'LAB CLASS', 'Information Management 1', '2024-04-15', '2-B', 'expired'),
(4, 'NO CLASS BASTA', 'NONE', '2024-04-16', '2-B', 'expired'),
(5, 'NO CLASS BASTA', 'NONE', '2024-04-20', '2-B', 'active');

-- --------------------------------------------------------

--
-- Table structure for table `event_schedule`
--

CREATE TABLE `event_schedule` (
  `id` int NOT NULL,
  `title` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  `date` date NOT NULL,
  `year_section` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `event_schedule`
--

INSERT INTO `event_schedule` (`id`, `title`, `type`, `date`, `year_section`, `status`) VALUES
(2, 'meeting', 'SSC', '2024-04-24', '2-A', ''),
(3, 'MEETING', 'DEPARTMENT', '2024-04-17', '2-B', 'active'),
(4, 'MEETING', 'SSC', '2024-04-20', '2-B', 'active'),
(5, 'MEETING', 'DEPARTMENT', '2024-04-17', '2-B', 'active');

-- --------------------------------------------------------

--
-- Table structure for table `learningmaterials`
--

CREATE TABLE `learningmaterials` (
  `id` int NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text,
  `google_drive_link` varchar(255) NOT NULL,
  `year_section` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `learningmaterials`
--

INSERT INTO `learningmaterials` (`id`, `title`, `description`, `google_drive_link`, `year_section`) VALUES
(1, 'Quantitative Methods', 'MIDTERM MATERIAL', 'https://drive.google.com/drive/folders/1-VlqPtM5IXBVH9Co4HhcBSFTpZI2PP4Z?usp=sharing', ''),
(2, 'Quantitative Methods', 'MIDTERM MATERIALS', 'https://drive.google.com/drive/folders/1-VlqPtM5IXBVH9Co4HhcBSFTpZI2PP4Z?usp=sharing', '2-B'),
(3, 'Quantitative Methods', 'MIDTERM MATERIAL', 'https://drive.google.com/drive/folders/1-VlqPtM5IXBVH9Co4HhcBSFTpZI2PP4Z?usp=sharing', '2-A'),
(4, 'Database Administration', 'RELATIONAL DATABASE', 'https://drive.google.com/drive/folders/11Vzp1o2YbKkIVx6qXVOwLfYr7YQpBxe5?usp=sharing', '2-B'),
(5, 'Network Basics', 'CHAPTER 1 - 6', 'https://drive.google.com/drive/folders/1Ya29oEXGlgw1vJdIIhg-hT3FMwndpr3I?usp=sharing', '2-B');

-- --------------------------------------------------------

--
-- Table structure for table `registrar`
--

CREATE TABLE `registrar` (
  `id` int NOT NULL,
  `student_ID` varchar(20) DEFAULT NULL,
  `priority_queue_number` int DEFAULT NULL,
  `time` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `status` varchar(255) NOT NULL,
  `s_stat` varchar(255) NOT NULL,
  `num_attempts` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `registrar`
--

INSERT INTO `registrar` (`id`, `student_ID`, `priority_queue_number`, `time`, `status`, `s_stat`, `num_attempts`) VALUES
(573, '2210132-1', 3001, '2024-03-31 04:44:26', 'expired', 'served', '5'),
(574, '2210132-1', 3002, '2024-03-31 04:45:34', 'expired', 'served', '4'),
(575, '2210132-1', 3003, '2024-03-31 04:45:41', 'expired', 'served', '3'),
(576, '2210132-1', 3004, '2024-03-31 04:45:47', 'expired', 'served', '2'),
(577, '2210132-1', 3005, '2024-03-31 04:45:53', 'expired', 'served', '1');

-- --------------------------------------------------------

--
-- Table structure for table `sas`
--

CREATE TABLE `sas` (
  `id` int NOT NULL,
  `student_ID` varchar(20) DEFAULT NULL,
  `priority_queue_number` int DEFAULT NULL,
  `time` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `status` varchar(255) NOT NULL,
  `s_stat` varchar(255) NOT NULL,
  `num_attempts` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `sas`
--

INSERT INTO `sas` (`id`, `student_ID`, `priority_queue_number`, `time`, `status`, `s_stat`, `num_attempts`) VALUES
(148, '2210132-1', 3001, '2024-03-31 05:08:23', 'expired', 'served', '5');

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `ID` int NOT NULL,
  `student_ID` varchar(20) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`ID`, `student_ID`, `name`, `password`) VALUES
(11, '2210132-1', 'Manny Merino', 'manny'),
(12, '2210134-2', 'josephine bedon', 'manny');

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `id` int NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `section` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`id`, `username`, `password`, `section`) VALUES
(6, 'admin', 'admin', '2-B'),
(9, 'man', 'man', '2-A');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `admin_id` (`admin_id`);

--
-- Indexes for table `assessment_schedule`
--
ALTER TABLE `assessment_schedule`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cashier`
--
ALTER TABLE `cashier`
  ADD PRIMARY KEY (`id`),
  ADD KEY `student_ID` (`student_ID`);

--
-- Indexes for table `class_schedule`
--
ALTER TABLE `class_schedule`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `event_schedule`
--
ALTER TABLE `event_schedule`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `learningmaterials`
--
ALTER TABLE `learningmaterials`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `registrar`
--
ALTER TABLE `registrar`
  ADD PRIMARY KEY (`id`),
  ADD KEY `student_ID` (`student_ID`);

--
-- Indexes for table `sas`
--
ALTER TABLE `sas`
  ADD PRIMARY KEY (`id`),
  ADD KEY `student_ID` (`student_ID`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`ID`),
  ADD UNIQUE KEY `student_ID` (`student_ID`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `assessment_schedule`
--
ALTER TABLE `assessment_schedule`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `cashier`
--
ALTER TABLE `cashier`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1306;

--
-- AUTO_INCREMENT for table `class_schedule`
--
ALTER TABLE `class_schedule`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `event_schedule`
--
ALTER TABLE `event_schedule`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `learningmaterials`
--
ALTER TABLE `learningmaterials`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `registrar`
--
ALTER TABLE `registrar`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=578;

--
-- AUTO_INCREMENT for table `sas`
--
ALTER TABLE `sas`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=149;

--
-- AUTO_INCREMENT for table `student`
--
ALTER TABLE `student`
  MODIFY `ID` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `students`
--
ALTER TABLE `students`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `cashier`
--
ALTER TABLE `cashier`
  ADD CONSTRAINT `cashier_ibfk_1` FOREIGN KEY (`student_ID`) REFERENCES `student` (`student_ID`);

--
-- Constraints for table `registrar`
--
ALTER TABLE `registrar`
  ADD CONSTRAINT `registrar_ibfk_1` FOREIGN KEY (`student_ID`) REFERENCES `student` (`student_ID`);

--
-- Constraints for table `sas`
--
ALTER TABLE `sas`
  ADD CONSTRAINT `sas_ibfk_1` FOREIGN KEY (`student_ID`) REFERENCES `student` (`student_ID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
